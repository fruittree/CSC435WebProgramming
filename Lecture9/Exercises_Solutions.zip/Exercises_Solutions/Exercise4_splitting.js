string_to_array = function (str) {
     return str.trim().split(" ");
};
var s ="Monday is Blue"
alert(string_to_array(s));